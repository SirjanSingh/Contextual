# Repo-Aware AI Assistant (Local, Privacy-First)

A local "talk to your codebase" tool:
- Indexes a repository locally
- Retrieves relevant code chunks (RAG)
- Asks a local LLM via Ollama
- Answers with file references

## Tech stack
- LLM: Ollama (local) + `qwen2.5-coder:7b-instruct`
- Embeddings: `sentence-transformers` (`BAAI/bge-small-en-v1.5`, CPU)
- Vector store: FAISS (CPU)
- Language: Python 3.10+

## Setup

1) Create and activate a venv (recommended):

Windows PowerShell:
```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
```

2) Install dependencies:
```powershell
pip install -r requirements.txt
```

3) Ensure Ollama is installed and the model is present:
```powershell
ollama --version
ollama list
# if needed:
ollama pull qwen2.5-coder:7b-instruct
```

## Run

Index a repo and start a Q&A loop:
```powershell
python main.py --repo "C:\path\to\repo"
```

Force rebuild:
```powershell
python main.py --repo "C:\path\to\repo" --rebuild
```

## How it works (pipeline)

1. **Loader**: reads code files from disk, ignores junk directories.
2. **Chunker**: splits files into overlapping chunks.
3. **Embedder**: turns chunks into vectors.
4. **Indexer**: stores vectors + metadata in FAISS; caches on disk.
5. **Retriever**: finds top-k relevant chunks per question.
6. **LLM**: sends context + question to Ollama model.
7. **Answer**: prints answer + sources like `path:start-end`.

## Notes
- Local-first: your code stays on your machine.
- If the answer is not in retrieved context, the assistant should say it doesn't know.
- The cache is stored under `data/index/<repo_id>/`.

## Next improvements (optional)
- Line-level citations (use line ranges instead of char ranges)
- Token-based chunking
- FastAPI backend + UI
- VS Code extension
