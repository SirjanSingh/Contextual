from __future__ import annotations

from dataclasses import dataclass
from typing import List

import numpy as np
from sentence_transformers import SentenceTransformer


@dataclass
class Embedder:
    model_name: str = "BAAI/bge-small-en-v1.5"
    device: str = "cpu"

    def __post_init__(self) -> None:
        self.model = SentenceTransformer(self.model_name, device=self.device)

    def embed_texts(self, texts: List[str], batch_size: int = 64) -> np.ndarray:
        """
        Returns float32 normalized embeddings shaped (N, D).
        We use cosine similarity via inner product on normalized vectors.
        """
        emb = self.model.encode(
            texts,
            batch_size=batch_size,
            show_progress_bar=False,
            convert_to_numpy=True,
            normalize_embeddings=True,
        )
        if emb.dtype != np.float32:
            emb = emb.astype(np.float32)
        return emb

    def embed_query(self, query: str) -> np.ndarray:
        v = self.embed_texts([query], batch_size=1)
        return v[0]
