from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from tqdm import tqdm

from .loader import load_repo_files
from .chunker import chunk_files, Chunk
from .embedder import Embedder
from .indexer import build_or_load_index
from .retriever import retrieve, RetrievedChunk
from .llm import LLMClient


@dataclass
class QAEngine:
    repo_root: Path
    cache_base: Path
    embedder: Embedder
    llm: LLMClient
    chunk_size: int = 1800
    overlap: int = 250
    top_k: int = 6

    index = None
    metadata: List[Dict] | None = None
    cache_dir: Path | None = None

    def build(self, force_rebuild: bool = False) -> None:
        repo_files = load_repo_files(self.repo_root)
        chunks = chunk_files(repo_files, chunk_size=self.chunk_size, overlap=self.overlap)

        # Try to load index WITHOUT embedding first
        # (indexer will validate fingerprint and dim; if valid it returns loaded index)
        dummy_dim = 384  # bge-small dim
        import numpy as np
        dummy_emb = np.zeros((len(chunks), dummy_dim), dtype=np.float32)

        index, metadata, cdir = build_or_load_index(
            repo_root=self.repo_root,
            chunks=chunks,
            embeddings=dummy_emb,
            cache_base=self.cache_base,
            force_rebuild=False,
        )

        # If loaded successfully, metadata will exist and index will be present.
        # But if it rebuilt, it used dummy embeddings which is wrong.
        # So we detect rebuild by checking manifest num_chunks == len(chunks) AND index.ntotal == len(chunks).
        if (not force_rebuild) and index.ntotal == len(chunks) and len(metadata) == len(chunks):
            # Loaded OK (no rebuild happened)
            self.index = index
            self.metadata = metadata
            self.cache_dir = cdir
            return

        # Otherwise build real embeddings and rebuild properly
        texts = [c.text for c in chunks]
        emb = self.embedder.embed_texts(texts, batch_size=64)

        index, metadata, cdir = build_or_load_index(
            repo_root=self.repo_root,
            chunks=chunks,
            embeddings=emb,
            cache_base=self.cache_base,
            force_rebuild=True,
        )
        self.index = index
        self.metadata = metadata
        self.cache_dir = cdir


    def ask(self, question: str) -> Tuple[str, List[str]]:
        if self.index is None or self.metadata is None:
            raise RuntimeError("Index not built. Call build() first.")

        chunks = retrieve(
            index=self.index,
            metadata=self.metadata,
            embedder=self.embedder,
            question=question,
            top_k=self.top_k,
        )

        answer = self.llm.answer(question, chunks)

        sources = []
        for c in chunks:
            sources.append(f"{c.source}:{c.start_char}-{c.end_char}")
        return answer, sources
