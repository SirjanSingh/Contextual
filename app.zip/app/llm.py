from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional

import ollama

from .retriever import RetrievedChunk


SYSTEM_PROMPT = """You are a repo-aware coding assistant.
You MUST answer using only the provided repository context.
If the answer is not in the context, say: "I don't know from the given repo context."

Rules:
- Be precise and practical.
- When you make a claim, cite sources as: (source: path:start-end)
- Prefer bullet points and short sections.
- Do NOT invent files, functions, endpoints, or behavior not present in the context.
"""


def _format_context(chunks: List[RetrievedChunk], max_chars: int = 15000) -> str:
    """
    Build a compact context block. Keep within a safe budget.
    """
    parts: List[str] = []
    used = 0
    for c in chunks:
        header = f"\n---\nFILE: {c.source} [{c.start_char}-{c.end_char}] (score={c.score:.3f})\n"
        body = c.text.strip()
        block = header + body + "\n"
        if used + len(block) > max_chars:
            break
        parts.append(block)
        used += len(block)
    return "".join(parts).strip()


@dataclass
class LLMClient:
    model: str = "qwen2.5-coder:7b-instruct"
    temperature: float = 0.2

    def answer(self, question: str, chunks: List[RetrievedChunk]) -> str:
        context = _format_context(chunks)

        user_prompt = f"""REPO CONTEXT:
{context}

QUESTION:
{question}

Write the answer now. Remember: cite sources as (source: path:start-end).
"""

        try:
            resp = ollama.chat(
                model=self.model,
                messages=[
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": user_prompt},
                ],
                options={"temperature": self.temperature, "num_ctx": 2048},
            )
            return (resp.get("message", {}) or {}).get("content", "").strip()
        except Exception as e:
            return f"LLM error: {e}\n\nTip: ensure Ollama is running and the model name is correct."
